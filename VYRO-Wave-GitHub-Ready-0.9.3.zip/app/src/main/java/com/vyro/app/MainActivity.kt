package com.vyro.app

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL

private const val PREFS = "vyro_session"
private const val API = BuildConfig.API_BASE_URL

data class Video(val id: String, val url: String, val user: String, val caption: String, val likes: Int)
data class Me(val id: String, val username: String, val displayName: String, val bio: String)
enum class Tab { HOME, LIVE, CREATE, INBOX, PROFILE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { WaveTheme { WaveApp() } }
    }
}

@Composable
private fun WaveTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8B6CFF),
            onPrimary = Color.White,
            background = Color(0xFF0B0B0F),
            surface = Color(0xFF111116),
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@Composable
fun WaveApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var token by remember {
        mutableStateOf(context.getSharedPreferences(PREFS, 0).getString("token", null))
    }
    var tab by remember { mutableStateOf(Tab.HOME) }
    var videos by remember { mutableStateOf<List<Video>>(emptyList()) }
    var me by remember { mutableStateOf<Me?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    suspend fun ensureSession() {
        if (token.isNullOrBlank()) {
            val newToken = Api.session()
            token = newToken
            context.getSharedPreferences(PREFS, 0).edit().putString("token", newToken).apply()
        }
    }

    fun loadData() {
        scope.launch {
            busy = true
            message = null
            try {
                ensureSession()
                val t = token!!
                videos = Api.feed(t)
                me = Api.me(t)
            } catch (e: Exception) {
                // Keep the UI visible even if the backend is temporarily unavailable.
                message = e.message ?: "تعذر الاتصال بالخادم"
            } finally {
                busy = false
            }
        }
    }

    LaunchedEffect(Unit) { loadData() }

    Scaffold(
        containerColor = Color(0xFF0B0B0F),
        topBar = { WaveTopBar() },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF050507)) {
                NavItem(Tab.HOME, Icons.Default.Home, "الرئيسية", tab) { tab = it }
                NavItem(Tab.LIVE, Icons.Default.LiveTv, "مباشر", tab) { tab = it }
                NavItem(Tab.CREATE, Icons.Default.AddCircle, "إنشاء", tab) { tab = it }
                NavItem(Tab.INBOX, Icons.Default.Notifications, "الإشعارات", tab) { tab = it }
                NavItem(Tab.PROFILE, Icons.Default.Person, "حسابي", tab) { tab = it }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                Tab.HOME -> Home(videos, busy, message) { loadData() }
                Tab.LIVE -> Live(token, { busy = it }) { message = it }
                Tab.CREATE -> Create(token, { busy = it }) { msg ->
                    message = msg
                    loadData()
                }
                Tab.INBOX -> Inbox()
                Tab.PROFILE -> Profile(me) { name, bio ->
                    scope.launch {
                        try {
                            ensureSession()
                            me = Api.profile(token!!, name, bio)
                            message = "تم حفظ الملف"
                        } catch (e: Exception) {
                            message = e.message ?: "تعذر حفظ الملف"
                        }
                    }
                }
            }

            if (busy) {
                LinearProgressIndicator(
                    Modifier.fillMaxWidth().align(Alignment.TopCenter)
                )
            }

            message?.let {
                Surface(
                    modifier = Modifier.align(Alignment.TopCenter).padding(12.dp),
                    color = Color(0xFF24242A),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text(it, color = Color.White, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}

@Composable
private fun WaveTopBar() {
    Surface(color = Color(0xFF111116)) {
        Row(
            Modifier.fillMaxWidth().height(62.dp).padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("W", color = Color(0xFF7C5CFF), style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(6.dp))
            Text("AVE", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.weight(1f))
            Text("WAVE LIVE", color = Color.LightGray, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
private fun NavItem(
    tab: Tab,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Tab,
    onSelect: (Tab) -> Unit
) {
    NavigationBarItem(
        selected = tab == selected,
        onClick = { onSelect(tab) },
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}

@Composable
private fun Home(videos: List<Video>, busy: Boolean, error: String?, retry: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xFF0B0B0F))) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("مرحباً بك في Wave", color = Color.White, style = MaterialTheme.typography.titleLarge)
                Text("اكتشف البث والفيديوهات", color = Color.Gray)
            }
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF7C5CFF))
        }

        if (busy && videos.isEmpty()) {
            EmptyState("جاري تحميل Wave", "واجهة التطبيق تعمل. انتظر لحظات…", null)
        } else if (error != null && videos.isEmpty()) {
            EmptyState("Wave جاهز للعمل", "الخادم غير متاح حالياً، لكن التطبيق يعمل. اضغط لإعادة المحاولة.", retry)
        } else if (videos.isEmpty()) {
            EmptyState("مرحباً بك في Wave", "ابدأ أول بث أو انشر أول فيديو.", retry)
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(videos, key = { it.id }) { video -> VideoCard(video) }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String, retry: (() -> Unit)?) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("WAVE", color = Color.White, style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(12.dp))
            Text(title, color = Color.White, style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(6.dp))
            Text(subtitle, color = Color.Gray)
            if (retry != null) {
                Spacer(Modifier.height(18.dp))
                Button(onClick = retry) { Text("إعادة المحاولة") }
            }
        }
    }
}

@Composable
private fun VideoCard(video: Video) {
    var liked by remember(video.id) { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(bottom = 18.dp)) {
        Box(Modifier.fillMaxWidth().height(520.dp)) {
            Player(video.url)
            Column(
                Modifier.align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color(0x66000000))
                    .padding(16.dp)
            ) {
                Text("@${video.user}", color = Color.White, style = MaterialTheme.typography.titleMedium)
                if (video.caption.isNotBlank()) Text(video.caption, color = Color.White)
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton({ liked = !liked }) {
                Icon(
                    if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "إعجاب",
                    tint = if (liked) Color(0xFFFF4F7B) else Color.White
                )
            }
            Text(video.likes.toString(), color = Color.White)
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Default.ChatBubble, contentDescription = "تعليقات", tint = Color.White)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.Share, contentDescription = "مشاركة", tint = Color.White)
        }
    }
}

@Composable
private fun Player(url: String) {
    val context = LocalContext.current
    val player = remember(url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(url))
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    AndroidView(
        factory = { PlayerView(it).apply { useController = true; this.player = player } },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun Live(token: String?, setBusy: (Boolean) -> Unit, onMessage: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    var rtmps by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("البث المباشر", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "أنشئ بثاً مباشراً عبر Cloudflare Stream ثم استخدم بيانات RTMPS في برنامج البث.",
            color = Color.LightGray
        )
        Spacer(Modifier.height(20.dp))
        Button(
            enabled = !token.isNullOrBlank(),
            onClick = {
                scope.launch {
                    setBusy(true)
                    try {
                        val result = Api.live(token!!)
                        rtmps = result.rtmps
                        key = result.key
                        onMessage("تم إنشاء قناة البث")
                    } catch (e: Exception) {
                        onMessage(e.message ?: "فشل إنشاء البث")
                    } finally {
                        setBusy(false)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("إنشاء بث مباشر") }

        if (rtmps.isNotBlank()) {
            Spacer(Modifier.height(20.dp))
            Text("RTMPS URL", color = Color.Gray)
            Text(rtmps, color = Color.White)
            Spacer(Modifier.height(10.dp))
            Text("STREAM KEY", color = Color.Gray)
            Text(key, color = Color.White)
        }
    }
}

@Composable
private fun Create(token: String?, setBusy: (Boolean) -> Unit, done: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var caption by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        selected = it
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("إنشاء فيديو", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text("وصف الفيديو") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { picker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
            Text(if (selected == null) "اختيار فيديو من الهاتف" else "تم اختيار الفيديو")
        }
        Spacer(Modifier.height(12.dp))
        Button(
            enabled = selected != null && !token.isNullOrBlank(),
            onClick = {
                scope.launch {
                    setBusy(true)
                    status = "جاري الرفع…"
                    try {
                        val ticket = Api.directUpload(token!!)
                        val id = Api.uploadFile(context, selected!!, ticket.uploadUrl)
                        Api.createVideo(token, id, caption)
                        status = "تم النشر بنجاح"
                        done(status)
                    } catch (e: Exception) {
                        status = e.message ?: "فشل الرفع"
                        done(status)
                    } finally {
                        setBusy(false)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("رفع ونشر") }
        if (status.isNotBlank()) Text(status, color = Color.White, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun Inbox() {
    EmptyState("الإشعارات", "ستظهر هنا الإعجابات والمتابعات والهدايا.", null)
}

@Composable
private fun Profile(me: Me?, save: (String, String) -> Unit) {
    var name by remember(me?.displayName) { mutableStateOf(me?.displayName.orEmpty()) }
    var bio by remember(me?.bio) { mutableStateOf(me?.bio.orEmpty()) }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("حسابي", color = Color.White, style = MaterialTheme.typography.headlineMedium)
        Text("@${me?.username ?: "guest"}", color = Color.LightGray)
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("الاسم") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = bio,
            onValueChange = { bio = it },
            label = { Text("نبذة") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = { save(name, bio) }, modifier = Modifier.fillMaxWidth()) {
            Text("حفظ الملف")
        }
    }
}

data class UploadTicket(val uploadUrl: String, val id: String)
data class LiveResult(val rtmps: String, val key: String)

object Api {
    private fun conn(path: String, method: String, token: String? = null): HttpURLConnection =
        (URL(API + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 15000
            readTimeout = 30000
            if (token != null) setRequestProperty("Authorization", "Bearer $token")
            if (method == "POST" || method == "PATCH") {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }

    private fun body(c: HttpURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            throw IllegalStateException(JSONObject(text).optString("error", "HTTP $code"))
        }
        return text
    }

    suspend fun session() = withContext(Dispatchers.IO) {
        val c = conn("/api/session", "POST")
        try { JSONObject(body(c)).getString("token") } finally { c.disconnect() }
    }

    suspend fun feed(t: String) = withContext(Dispatchers.IO) {
        val c = conn("/api/feed?limit=30", "GET", t)
        try {
            val a = JSONObject(body(c)).optJSONArray("items") ?: JSONArray()
            List(a.length()) {
                val o = a.getJSONObject(it)
                Video(o.getString("id"), o.getString("url"), o.getString("user"), o.optString("caption"), o.optInt("likes"))
            }
        } finally { c.disconnect() }
    }

    suspend fun me(t: String) = withContext(Dispatchers.IO) {
        val c = conn("/api/me", "GET", t)
        try {
            val o = JSONObject(body(c)).getJSONObject("user")
            Me(o.getString("id"), o.getString("username"), o.optString("displayName"), o.optString("bio"))
        } finally { c.disconnect() }
    }

    suspend fun profile(t: String, name: String, bio: String) = withContext(Dispatchers.IO) {
        val c = conn("/api/profile", "PATCH", t)
        try {
            c.outputStream.use {
                it.write(JSONObject().put("displayName", name).put("bio", bio).toString().toByteArray())
            }
            val o = JSONObject(body(c)).getJSONObject("user")
            Me(o.getString("id"), o.getString("username"), o.optString("displayName"), o.optString("bio"))
        } finally { c.disconnect() }
    }

    suspend fun directUpload(t: String) = withContext(Dispatchers.IO) {
        val c = conn("/api/upload/direct", "POST", t)
        try {
            val r = JSONObject(body(c)).getJSONObject("result")
            UploadTicket(r.getString("uploadURL"), r.getString("uid"))
        } finally { c.disconnect() }
    }

    suspend fun createVideo(t: String, id: String, caption: String) = withContext(Dispatchers.IO) {
        val c = conn("/api/videos", "POST", t)
        try {
            c.outputStream.use {
                it.write(JSONObject().put("streamId", id).put("caption", caption).toString().toByteArray())
            }
            body(c)
        } finally { c.disconnect() }
    }

    suspend fun uploadFile(context: Context, uri: Uri, uploadUrl: String) =
        withContext(Dispatchers.IO) {
            val boundary = "----VYRO${System.currentTimeMillis()}"
            val c = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 30000
                readTimeout = 120000
                setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            }
            try {
                DataOutputStream(c.outputStream).use { out ->
                    out.writeBytes("--$boundary\r\n")
                    out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"video.mp4\"\r\n")
                    out.writeBytes("Content-Type: video/mp4\r\n\r\n")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n <= 0) break
                            out.write(buffer, 0, n)
                        }
                    } ?: throw IllegalStateException("Cannot read selected file")
                    out.writeBytes("\r\n--$boundary--\r\n")
                }
                if (c.responseCode !in 200..299) throw IllegalStateException("Upload failed: HTTP ${c.responseCode}")
                JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                    .optJSONObject("result")?.optString("uid")
                    ?.takeIf { it.isNotBlank() }
                    ?: throw IllegalStateException("Cloudflare did not return a video id")
            } finally { c.disconnect() }
        }

    suspend fun live(t: String) = withContext(Dispatchers.IO) {
        val c = conn("/api/live/create", "POST", t)
        try {
            val r = JSONObject(body(c)).getJSONObject("result")
            val rt = r.optJSONObject("rtmps")
                ?: throw IllegalStateException("Cloudflare did not return RTMPS credentials")
            LiveResult(rt.optString("url"), rt.optString("streamKey"))
        } finally { c.disconnect() }
    }
}
