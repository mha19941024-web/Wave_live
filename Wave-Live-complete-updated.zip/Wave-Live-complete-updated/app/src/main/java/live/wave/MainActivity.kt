package live.wave

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val WaveBg = Color(0xFF080B14)
private val WaveSurface = Color(0xFF121827)
private val WaveAccent = Color(0xFF6C63FF)

data class LiveRoom(val host: String, val title: String, val viewers: String, val category: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { WaveLiveApp() } }
}

@Composable
fun WaveLiveApp() {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(background = WaveBg, surface = WaveSurface, primary = WaveAccent)) {
        Scaffold(containerColor = WaveBg, bottomBar = {
            NavigationBar(containerColor = WaveSurface) {
                listOf("الرئيسية","مباشر","الهدايا","حسابي").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Text(listOf("⌂","●","♛","☺")[i], fontSize = 20.sp) }, label = { Text(label) })
                }
            }
        }) { p -> when (tab) { 0 -> HomeScreen(Modifier.padding(p)); 1 -> LiveScreen(Modifier.padding(p)); 2 -> GiftsScreen(Modifier.padding(p)); else -> ProfileScreen(Modifier.padding(p)) } }
    }
}

@Composable fun HomeScreen(modifier: Modifier) {
    val rooms = listOf(LiveRoom("Wave Star","سهرة Wave الآن 🔴","2.4K","موسيقى"),LiveRoom("Ahmed Live","تعالوا نتكلم ونضحك","1.1K","دردشة"),LiveRoom("Football Wave","تحليل المباريات مباشر","840","رياضة"))
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Wave Live", fontSize = 30.sp, fontWeight = FontWeight.Bold); Text("اكتشف البثوث المباشرة", color = Color(0xFFA8B0C0)); Spacer(Modifier.height(12.dp)) }
        items(rooms) { LiveCard(it) }
    }
}

@Composable fun LiveCard(room: LiveRoom) {
    Card(Modifier.fillMaxWidth().clickable {}, shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = WaveSurface)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).background(WaveAccent, CircleShape), contentAlignment = Alignment.Center) { Text("W", fontWeight = FontWeight.Bold, fontSize = 22.sp) }
                Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(room.host, fontWeight = FontWeight.Bold); Text(room.title, color = Color(0xFFD6DAE5)) }; Text("🔴 ${room.viewers}")
            }
            Spacer(Modifier.height(12.dp)); Surface(color = Color(0xFF1C2233), shape = RoundedCornerShape(12.dp)) { Text(room.category, Modifier.padding(horizontal = 12.dp, vertical = 7.dp)) }
        }
    }
}

@Composable fun LiveScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("البث المباشر", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("ابدأ بثك أو ادخل إلى غرفة مباشرة.", color = Color(0xFFA8B0C0))
        Button(onClick = {}, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("ابدأ بث مباشر") }
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("إنشاء غرفة") }
    }
}

@Composable fun GiftsScreen(modifier: Modifier) {
    val gifts = listOf("👑 التاج الدوار","🦁 الأسد","🐯 النمر","💎 الماسة","🌹 الوردة")
    Column(modifier.fillMaxSize().padding(20.dp)) {
        Text("هدايا Wave", fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("هدايا رقمية أثناء البث", color = Color(0xFFA8B0C0)); Spacer(Modifier.height(18.dp))
        gifts.forEachIndexed { i, gift -> Card(Modifier.fillMaxWidth().padding(bottom = 10.dp), colors = CardDefaults.cardColors(containerColor = WaveSurface)) { Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(gift, Modifier.weight(1f), fontSize = 20.sp); Text("${(i + 1) * 50} عملة", color = WaveAccent) } } }
    }
}

@Composable fun ProfileScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp)); Box(Modifier.size(90.dp).background(WaveAccent, CircleShape), contentAlignment = Alignment.Center) { Text("W", fontSize = 40.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(14.dp)); Text("حساب Wave", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("الرصيد: 0 عملة", color = Color(0xFFA8B0C0)); Spacer(Modifier.height(24.dp)); OutlinedButton(onClick = {}, Modifier.fillMaxWidth()) { Text("تسجيل الدخول") }
    }
}
